<?php
$hook_array['before_save'][] = Array(66, 'Description of logic', 'custom/modules/Accounts/custom_logic_hooks.php','ourCustomLogicHooks', 'update_check_date');