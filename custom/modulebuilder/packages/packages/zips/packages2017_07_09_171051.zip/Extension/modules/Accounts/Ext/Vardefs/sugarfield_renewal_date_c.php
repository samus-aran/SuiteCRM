<?php
 // created: 2017-07-09 15:47:16
$dictionary['Account']['fields']['renewal_date_c']['inline_edit']='1';
$dictionary['Account']['fields']['renewal_date_c']['labelValue']='Renewal Date';

 ?>