<?php
 // created: 2017-07-06 12:06:45
$dictionary['Account']['fields']['jjwg_maps_lng_c']['inline_edit']=1;

 ?>