<?php 
 // created: 2017-07-09 17:10:50
$mod_strings['LBL_TYPE'] = 'Type:';
$mod_strings['LBL_RENEWAL_DATE'] = 'Renewal Date';

?>
