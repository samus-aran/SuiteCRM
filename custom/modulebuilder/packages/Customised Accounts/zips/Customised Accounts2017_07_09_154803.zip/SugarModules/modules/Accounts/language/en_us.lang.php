<?php 
 // created: 2017-07-09 15:48:01
$mod_strings['LBL_TYPE'] = 'Type:';
$mod_strings['LBL_RENEWAL_DATE'] = 'Renewal Date';

?>
