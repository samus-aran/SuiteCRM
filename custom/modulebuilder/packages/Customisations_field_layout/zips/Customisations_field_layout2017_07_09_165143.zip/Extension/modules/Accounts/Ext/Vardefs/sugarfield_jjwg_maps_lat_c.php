<?php
 // created: 2017-07-06 12:06:45
$dictionary['Account']['fields']['jjwg_maps_lat_c']['inline_edit']=1;

 ?>