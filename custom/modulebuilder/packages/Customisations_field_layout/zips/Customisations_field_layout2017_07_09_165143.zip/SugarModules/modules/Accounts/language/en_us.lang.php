<?php 
 // created: 2017-07-09 16:51:42
$mod_strings['LBL_TYPE'] = 'Type:';
$mod_strings['LBL_RENEWAL_DATE'] = 'Renewal Date';

?>
