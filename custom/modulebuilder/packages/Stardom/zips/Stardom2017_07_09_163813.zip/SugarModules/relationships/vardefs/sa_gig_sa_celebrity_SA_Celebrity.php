<?php
// created: 2017-07-09 16:38:13
$dictionary["SA_Celebrity"]["fields"]["sa_gig_sa_celebrity"] = array (
  'name' => 'sa_gig_sa_celebrity',
  'type' => 'link',
  'relationship' => 'sa_gig_sa_celebrity',
  'source' => 'non-db',
  'module' => 'SA_Gig',
  'bean_name' => false,
  'vname' => 'LBL_SA_GIG_SA_CELEBRITY_FROM_SA_GIG_TITLE',
);
