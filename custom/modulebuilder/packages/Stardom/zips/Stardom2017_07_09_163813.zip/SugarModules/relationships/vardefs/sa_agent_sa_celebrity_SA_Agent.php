<?php
// created: 2017-07-09 16:38:13
$dictionary["SA_Agent"]["fields"]["sa_agent_sa_celebrity"] = array (
  'name' => 'sa_agent_sa_celebrity',
  'type' => 'link',
  'relationship' => 'sa_agent_sa_celebrity',
  'source' => 'non-db',
  'module' => 'SA_Celebrity',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_SA_AGENT_SA_CELEBRITY_FROM_SA_CELEBRITY_TITLE',
);
