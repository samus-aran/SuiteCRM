<?php
// created: 2017-07-09 16:38:13
$dictionary["SA_Gig"]["fields"]["sa_gig_sa_agent"] = array (
  'name' => 'sa_gig_sa_agent',
  'type' => 'link',
  'relationship' => 'sa_gig_sa_agent',
  'source' => 'non-db',
  'module' => 'SA_Agent',
  'bean_name' => false,
  'vname' => 'LBL_SA_GIG_SA_AGENT_FROM_SA_AGENT_TITLE',
);
